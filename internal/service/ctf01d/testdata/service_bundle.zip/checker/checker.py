#!/usr/bin/env python3
print("checker ok")
