#!/usr/bin/env python3
print("standalone checker")
